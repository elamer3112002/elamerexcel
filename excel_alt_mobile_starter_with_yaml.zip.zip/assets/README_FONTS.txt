ضع هنا ملف خط عربي TrueType مثل Cairo-Regular.ttf أو NotoNaskhArabic-Regular.ttf
ثم حدث pubspec.yaml ليشمل المسار (تم إعداده بالفعل).
هذا ضروري ليظهر PDF بالعربية بشكل صحيح.