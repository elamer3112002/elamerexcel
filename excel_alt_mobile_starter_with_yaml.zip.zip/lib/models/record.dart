class Record {
  int? id;
  String اسم_البنك;
  String القطاع;
  String النوع; // مركز/هنجر/شونة/مجمع/القيمة/م.ت منقول.../م.ت اجمالى مسلم/زيادات
  double السعة;
  String المورد;
  String اسم_الأمين;
  String اسم_الفراز;
  String المورد_بالدرجات; // نص حر
  double الكمية; // بصيغة ثلاث منازل 55.680
  double المنقول_للصوامع;
  double المسلم_للمطاحن;
  double الزيادات;
  double الأرصدة;
  String برامج_السحب;
  String? ملفPDF; // مسار ملف
  int السنة;

  Record({
    this.id,
    required this.اسم_البنك,
    required this.القطاع,
    required this.النوع,
    required this.السعة,
    required this.المورد,
    required this.اسم_الأمين,
    required this.اسم_الفراز,
    required this.المورد_بالدرجات,
    required this.الكمية,
    required this.المنقول_للصوامع,
    required this.المسلم_للمطاحن,
    required this.الزيادات,
    required this.الأرصدة,
    required this.برامج_السحب,
    required this.السنة,
    this.ملفPDF,
  });

  Map<String, Object?> toMap() => {
    'id': id,
    'اسم_البنك': اسم_البنك,
    'القطاع': القطاع,
    'النوع': النوع,
    'السعة': السعة,
    'المورد': المورد,
    'اسم_الأمين': اسم_الأمين,
    'اسم_الفراز': اسم_الفراز,
    'المورد_بالدرجات': المورد_بالدرجات,
    'الكمية': الكمية,
    'المنقول_للصوامع': المنقول_للصوامع,
    'المسلم_للمطاحن': المسلم_للمطاحن,
    'الزيادات': الزيادات,
    'الأرصدة': الأرصدة,
    'برامج_السحب': برامج_السحب,
    'ملفPDF': ملفPDF,
    'السنة': السنة,
  };

  static Record fromMap(Map<String, Object?> m) => Record(
    id: m['id'] as int?,
    اسم_البنك: m['اسم_البنك'] as String,
    القطاع: m['القطاع'] as String,
    النوع: m['النوع'] as String,
    السعة: (m['السعة'] as num).toDouble(),
    المورد: m['المورد'] as String,
    اسم_الأمين: m['اسم_الأمين'] as String,
    اسم_الفراز: m['اسم_الفراز'] as String,
    المورد_بالدرجات: m['المورد_بالدرجات'] as String,
    الكمية: (m['الكمية'] as num).toDouble(),
    المنقول_للصوامع: (m['المنقول_للصوامع'] as num).toDouble(),
    المسلم_للمطاحن: (m['المسلم_للمطاحن'] as num).toDouble(),
    الزيادات: (m['الزيادات'] as num).toDouble(),
    الأرصدة: (m['الأرصدة'] as num).toDouble(),
    برامج_السحب: m['برامج_السحب'] as String,
    ملفPDF: m['ملفPDF'] as String?,
    السنة: m['السنة'] as int,
  );
}