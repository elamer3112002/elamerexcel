import 'package:flutter/material.dart';
import '../db/app_db.dart';
import '../models/record.dart';
import 'input_screen.dart';
import 'reports_screen.dart';

class TabsScreen extends StatefulWidget {
  const TabsScreen({super.key});

  @override
  State<TabsScreen> createState() => _TabsScreenState();
}

class _TabsScreenState extends State<TabsScreen> {
  final _types = const [
    'مراكز تجميع',
    'هناجر',
    'شون',
    'مجمع',
    'القيمة',
    'م.ت منقول للصوامع ومسلم للمطاحن',
    'م.ت اجمالى مسلم',
    'زيادات',
  ];
  int _year = DateTime.now().year;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: _types.length,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('دفاتر عربية — A4 جاهز للطباعة'),
          bottom: TabBar(isScrollable: true, tabs: _types.map((e)=>Tab(text: e)).toList()),
          actions: [
            IconButton(
              tooltip: 'تقارير',
              onPressed: ()=>Navigator.pushNamed(context, ReportsScreen.routeName, arguments: _year),
              icon: const Icon(Icons.bar_chart),
            ),
            Row(children: [
              IconButton(onPressed: ()=> setState(()=>_year--), icon: const Icon(Icons.remove)),
              Text('$_year', style: const TextStyle(fontWeight: FontWeight.bold)),
              IconButton(onPressed: ()=> setState(()=>_year++), icon: const Icon(Icons.add)),
            ]),
          ],
        ),
        body: Directionality(
          textDirection: TextDirection.rtl,
          child: TabBarView(
            children: _types.map((type) => _TypeList(type: type, year: _year)).toList(),
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: ()=>Navigator.pushNamed(context, InputScreen.routeName),
          icon: const Icon(Icons.add),
          label: const Text('سجل جديد'),
        ),
      ),
    );
  }
}

class _TypeList extends StatelessWidget {
  final String type;
  final int year;
  const _TypeList({required this.type, required this.year});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Record>>(
      future: AppDB.instance.queryByType(type, year),
      builder: (ctx, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final items = snap.data!;
        if (items.isEmpty) return const Center(child: Text('لا توجد سجلات لهذه السنة.'));
        return ListView.separated(
          itemCount: items.length,
          separatorBuilder: (_, __)=>const Divider(),
          itemBuilder: (_, i){
            final r = items[i];
            return ListTile(
              title: Text('${r.المورد} — ${r.الكمية.toStringAsFixed(3)}'),
              subtitle: Text('السعة: ${r.السعة.toStringAsFixed(3)} · الأمين: ${r.اسم_الأمين} · ${r.اسم_الفراز}'),
              trailing: Text(r.النوع),
            );
          },
        );
      },
    );
  }
}