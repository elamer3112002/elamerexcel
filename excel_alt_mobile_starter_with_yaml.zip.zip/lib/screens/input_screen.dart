import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:file_picker/file_picker.dart';
import '../db/app_db.dart';
import '../models/record.dart';

class InputScreen extends StatefulWidget {
  static const routeName = '/input';
  const InputScreen({super.key});

  @override
  State<InputScreen> createState() => _InputScreenState();
}

class _InputScreenState extends State<InputScreen> {
  final _formKey = GlobalKey<FormState>();
  final _numFormat = NumberFormat('##0.000', 'ar_EG');

  final _types = const [
    'مراكز تجميع',
    'هناجر',
    'شون',
    'مجمع',
    'القيمة',
    'م.ت منقول للصوامع ومسلم للمطاحن',
    'م.ت اجمالى مسلم',
    'زيادات',
  ];

  String? _اسم_البنك;
  String? _القطاع;
  String? _النوع;
  double? _السعة;
  String? _المورد;
  String? _اسم_الأمين;
  String? _اسم_الفراز;
  String? _المورد_بالدرجات;
  double? _الكمية;
  double? _المنقول_للصوامع;
  double? _المسلم_للمطاحن;
  double? _الزيادات;
  double? _الأرصدة;
  String? _برامج_السحب;
  String? _ملفPDF;
  int _السنة = DateTime.now().year;

  Future<void> _pickPDF() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    if (res != null && res.files.single.path != null) {
      setState(() {
        _ملفPDF = res.files.single.path;
      });
    }
  }

  String? _req(v) => (v==null || (v is String && v.trim().isEmpty)) ? 'مطلوب' : null;
  String? _reqNum(v) {
    if (v==null || v.toString().trim().isEmpty) return 'مطلوب';
    final n = double.tryParse(v.toString().replaceAll(',', '.'));
    if (n==null) return 'قيمة رقمية غير صحيحة';
    return null;
  }

  Widget _field({
    required String label,
    String? hint,
    TextInputType? type,
    String? Function(String?)? validator,
    void Function(String?)? onSaved,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: TextFormField(
        textDirection: TextDirection.rtl,
        keyboardType: type ?? TextInputType.text,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: const OutlineInputBorder(),
        ),
        validator: validator,
        onSaved: onSaved,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('شاشة الإدخال')),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Form(
            key: _formKey,
            child: ListView(
              children: [
                _field(label: 'اسم البنك', validator: _req, onSaved: (v)=>_اسم_البنك=v),
                _field(label: 'القطاع', validator: _req, onSaved: (v)=>_القطاع=v),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'نوع السجل'),
                  items: _types.map((e)=>DropdownMenuItem(value:e,child: Text(e))).toList(),
                  onChanged: (v)=>_النوع=v,
                  validator: _req,
                ),
                _field(label: 'السعة', hint:'مثال: 120.000', type: TextInputType.number, validator: _reqNum,
                  onSaved: (v)=>_السعة = double.parse(v!.replaceAll(',', '.'))),
                _field(label: 'المورد', validator: _req, onSaved: (v)=>_المورد=v),
                _field(label: 'اسم الأمين', validator: _req, onSaved: (v)=>_اسم_الأمين=v),
                _field(label: 'اسم الفراز', validator: _req, onSaved: (v)=>_اسم_الفراز=v),
                _field(label: 'المورد بدرجاته', validator: _req, onSaved: (v)=>_المورد_بالدرجات=v),
                _field(label: 'الكمية (مثال 55.680)', type: TextInputType.number, validator: _reqNum,
                  onSaved: (v)=>_الكمية = double.parse(v!.replaceAll(',', '.'))),
                _field(label: 'المنقول للصوامع', type: TextInputType.number, validator: _reqNum,
                  onSaved: (v)=>_المنقول_للصوامع = double.parse(v!.replaceAll(',', '.'))),
                _field(label: 'المسلم للمطاحن', type: TextInputType.number, validator: _reqNum,
                  onSaved: (v)=>_المسلم_للمطاحن = double.parse(v!.replaceAll(',', '.'))),
                _field(label: 'الزيادات', type: TextInputType.number, validator: _reqNum,
                  onSaved: (v)=>_الزيادات = double.parse(v!.replaceAll(',', '.'))),
                _field(label: 'الأرصدة', type: TextInputType.number, validator: _reqNum,
                  onSaved: (v)=>_الأرصدة = double.parse(v!.replaceAll(',', '.'))),
                _field(label: 'برامج السحب', validator: _req, onSaved: (v)=>_برامج_السحب=v),
                Row(
                  children: [
                    Expanded(child: Text('السنة: $_السنة')),
                    IconButton(onPressed: ()=> setState(()=>_السنة--), icon: const Icon(Icons.remove_circle_outline)),
                    IconButton(onPressed: ()=> setState(()=>_السنة++), icon: const Icon(Icons.add_circle_outline)),
                  ],
                ),
                Row(
                  children: [
                    Expanded(child: Text(_ملفPDF==null ? 'لم يتم اختيار ملف' : _ملفPDF!)),
                    ElevatedButton.icon(onPressed: _pickPDF, icon: const Icon(Icons.picture_as_pdf), label: const Text('رفع مستند PDF')),
                  ],
                ),
                const SizedBox(height: 12),
                ElevatedButton.icon(
                  icon: const Icon(Icons.save),
                  label: const Text('حفظ السجل'),
                  onPressed: () async {
                    if (_formKey.currentState!.validate()) {
                      _formKey.currentState!.save();
                      final r = Record(
                        اسم_البنك: _اسم_البنك!,
                        القطاع: _القطاع!,
                        النوع: _النوع!,
                        السعة: _السعة!,
                        المورد: _المورد!,
                        اسم_الأمين: _اسم_الأمين!,
                        اسم_الفراز: _اسم_الفراز!,
                        المورد_بالدرجات: _المورد_بالدرجات!,
                        الكمية: _الكمية!,
                        المنقول_للصوامع: _المنقول_للصوامع!,
                        المسلم_للمطاحن: _المسلم_للمطاحن!,
                        الزيادات: _الزيادات!,
                        الأرصدة: _الأرصدة!,
                        برامج_السحب: _برامج_السحب!,
                        ملفPDF: _ملفPDF,
                        السنة: _السنة,
                      );
                      await AppDB.instance.insert(r);
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم الحفظ')));
                        Navigator.pop(context);
                      }
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
      );
  }
}